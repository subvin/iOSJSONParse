//
//  ViewController.m
//  JSONLibTest
//
//  Created by Vincent Wang on 16/8/9.
//  Copyright © 2016年 subvin.inc. All rights reserved.
//

#import "ViewController.h"

#import "NSObject+YAJL.h"
#import "JSONKit.h"
#import "SBJson.h"
#import "CJSONSerializer.h"
#import "CJSONDeserializer.h"
#import "NXJsonParser.h"
#import "NXJsonSerializer.h"
#import "NXJsonParser.h"

#include <pthread.h>

@interface ViewController ()

@property (weak, nonatomic) IBOutlet UILabel *sysLabel;

@property (weak, nonatomic) IBOutlet UILabel *yajlLabel;

@property (weak, nonatomic) IBOutlet UILabel *jsonKitLabel;

@property (weak, nonatomic) IBOutlet UILabel *sbLabel;

@property (weak, nonatomic) IBOutlet UILabel *nextiveLabel;

@property (weak, nonatomic) IBOutlet UILabel *touchLabel;



@property (nonatomic,copy)NSString *jsonPath;

@end

@implementation ViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view, typically from a nib.
    
    _jsonPath = [[NSBundle mainBundle] pathForResource:@"jsondata" ofType:@".json"];
    
}

- (IBAction)sysParse:(id)sender {
    
    static int time = 0;//计算次数，用于算平均值
    static double cuTime = 0.f;
    
    NSData *theData = [NSData dataWithContentsOfFile:_jsonPath];
    NSError *err = nil;
    NSDate *beforeParseDate = [NSDate date];
    double beforeParse = [beforeParseDate timeIntervalSince1970];
    NSDictionary *dict = [NSJSONSerialization JSONObjectWithData:theData options:NSJSONReadingAllowFragments error:&err];
    if (dict) {
        NSDate *afterParseDate = [NSDate date];
        double afterParse = [afterParseDate timeIntervalSince1970];
        cuTime += (afterParse - beforeParse);
        time ++;
        _sysLabel.text = [NSString stringWithFormat:@"time mean : %.4fms",cuTime/time * 1000];
    }else
    {
        _sysLabel.text = @"Parse Error";
    }
}

- (IBAction)yajlParse:(id)sender {
    
    static int time = 0;//计算次数，用于算平均值
    static double cuTime = 0.f;
    
    NSData *theData = [NSData dataWithContentsOfFile:_jsonPath];
    NSError *err = nil;
    NSDate *beforeParseDate = [NSDate date];
    double beforeParse = [beforeParseDate timeIntervalSince1970];
    NSDictionary *dict =  [theData yajl_JSON:&err];
    if (dict) {
        NSDate *afterParseDate = [NSDate date];
        double afterParse = [afterParseDate timeIntervalSince1970];
        cuTime += (afterParse - beforeParse);
        time ++;
        _yajlLabel.text = [NSString stringWithFormat:@"mean time : %.4fms",cuTime/time * 1000];
    }else
    {
        _yajlLabel.text = @"Parse Error";
    }
}

- (IBAction)jsonKitParse:(id)sender {
    
    static int time = 0;//计算次数，用于算平均值
    static double cuTime = 0.f;
    
    NSData *theData = [NSData dataWithContentsOfFile:_jsonPath];
    NSError *err = nil;
    NSDate *beforeParseDate = [NSDate date];
    double beforeParse = [beforeParseDate timeIntervalSince1970];    
    NSDictionary *dict = [theData objectFromJSONData];
    
    
    if (dict) {
        NSDate *afterParseDate = [NSDate date];
        double afterParse = [afterParseDate timeIntervalSince1970];
        cuTime += (afterParse - beforeParse);
        time ++;
        _jsonKitLabel.text = [NSString stringWithFormat:@"time mean : %.4fms",cuTime/time * 1000];
    }else
    {
        _jsonKitLabel.text = @"Parse Error";
    }
}
- (IBAction)SBParse:(id)sender {
    
    static int time = 0;//计算次数，用于算平均值
    static double cuTime = 0.f;
    
    NSError *err = nil;
    NSDate *beforeParseDate = [NSDate date];
    double beforeParse = [beforeParseDate timeIntervalSince1970];
    SBJsonParser *parse = [[SBJsonParser alloc] init];
    NSString *string = [NSString stringWithContentsOfFile:_jsonPath encoding:NSUTF8StringEncoding error:&err ];
    NSDictionary *dict = [parse objectWithString:string] ;
    
    if (dict) {
        NSDate *afterParseDate = [NSDate date];
        double afterParse = [afterParseDate timeIntervalSince1970];
        cuTime += (afterParse - beforeParse);
        time ++;
        _sbLabel.text = [NSString stringWithFormat:@"time mean : %.4fms",cuTime/time * 1000];
    }else
    {
        _sbLabel.text = @"Parse Error";
    }
}
- (IBAction)nextiveParse:(id)sender {
    
    static int time = 0;//计算次数，用于算平均值
    static double cuTime = 0.f;
    NSError *err = nil;
    NSData *theData = [NSData dataWithContentsOfFile:_jsonPath];
    NSDate *beforeParseDate = [NSDate date];
    double beforeParse = [beforeParseDate timeIntervalSince1970];
    NXJsonParser * serializer = [[NXJsonParser alloc] init];
    NSDictionary *dict = [serializer parseData:theData error:&err ignoreNulls:YES];
    
    if (dict) {
        NSDate *afterParseDate = [NSDate date];
        double afterParse = [afterParseDate timeIntervalSince1970];
        cuTime += (afterParse - beforeParse);
        time ++;
        _nextiveLabel.text = [NSString stringWithFormat:@"time mean : %.4fms",cuTime/time * 1000];
    }else
    {
        _nextiveLabel.text = @"Parse Error";
    }
    
    
}
- (IBAction)touchParse:(id)sender {
    static int time = 0;//计算次数，用于算平均值
    static double cuTime = 0.f;
    NSData *theData = [NSData dataWithContentsOfFile:_jsonPath];
    NSDate *beforeParseDate = [NSDate date];
    double beforeParse = [beforeParseDate timeIntervalSince1970];
    
    CJSONDeserializer *deSerialise = [CJSONDeserializer deserializer];
    deSerialise.options |= kJSONDeserializationOptions_AllowFragments;
    NSError *theError = NULL;
    id dict = [deSerialise deserialize:theData error:&theError];
    
    if (dict) {
        NSDate *afterParseDate = [NSDate date];
        double afterParse = [afterParseDate timeIntervalSince1970];
        cuTime += (afterParse - beforeParse);
        time ++;
        _touchLabel.text = [NSString stringWithFormat:@"time mean : %.4fms",cuTime/time * 1000];
    }else
    {
        _touchLabel.text = @"Parse Error";
    }
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

@end
